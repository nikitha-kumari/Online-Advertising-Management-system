package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.Submit;

public interface SubmitRepository extends JpaRepository<Submit, String>
{

}
