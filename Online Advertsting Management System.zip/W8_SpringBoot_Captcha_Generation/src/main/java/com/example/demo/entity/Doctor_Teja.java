package com.example.demo.entity;

public class Doctor_Teja {
	int id;
	String name;
	String graduation;
	int age;
	String gender;
	Address adress;
	
	public Doctor_Teja(int id, String name, String graduation, int age, String gender, Address adress) {
		super();
		this.id = id;
		this.name = name;
		this.graduation = graduation;
		this.age = age;
		this.gender = gender;
		this.adress = adress;
	}
	
	public Doctor_Teja() {}

	@Override
	public String toString() {
		return "Doctor_Teja [id=" + id + ", name=" + name + ", graduation=" + graduation + ", age=" + age + ", gender="
				+ gender + ", adress=" + adress + "]";
	}
	
	
}
