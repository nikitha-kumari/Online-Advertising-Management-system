package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.Patient_Teja;

public interface Patient_TejaRespository extends JpaRepository<Patient_Teja, String>{

}

