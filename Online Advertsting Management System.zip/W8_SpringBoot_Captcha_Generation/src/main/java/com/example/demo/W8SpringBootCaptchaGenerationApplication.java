package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.demo.entity.Doctor_Teja;

@SpringBootApplication
public class W8SpringBootCaptchaGenerationApplication {

	public static void main(String[] args) {
		SpringApplication.run(W8SpringBootCaptchaGenerationApplication.class, args);
		ApplicationContext app = new ClassPathXmlApplicationContext("ApplicationContext.xml");
		Doctor_Teja d1 = (Doctor_Teja)app.getBean("d1");
		System.out.println("Doctor Details:");
		System.out.println("=========================================================");
		System.out.println(d1);
	}

}
