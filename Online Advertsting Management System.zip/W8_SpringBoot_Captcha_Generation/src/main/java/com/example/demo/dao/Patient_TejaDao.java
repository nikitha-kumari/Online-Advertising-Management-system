package com.example.demo.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Patient_Teja;
import com.example.demo.entity.Quiz;
import com.example.demo.entity.Submit;
import com.example.demo.repository.Patient_TejaRespository;
import com.example.demo.repository.QuizRepository;
import com.example.demo.repository.SubmitRepository;

@Service
public class Patient_TejaDao {
	
	@Autowired
	Patient_TejaRespository pgRepo;
	@Autowired
	SubmitRepository subRepo;
	@Autowired
	QuizRepository qRepo;
	public boolean validateLogin(Patient_Teja p) {
		if(pgRepo.existsById(p.getId())) {
			Patient_Teja pv =  pgRepo.getById(p.getId());
			if(pv.getPassword().equals(p.getPassword())) {
				return true;
			}
		}
		return false;
	}
	public Patient_Teja getDetailsById(Patient_Teja p) {
		return pgRepo.getById(p.getId());
	}

	public Patient_Teja getDetailsByIdOnly(String id) {
		return pgRepo.getById(id);		
	}
	
	public void insert(Patient_Teja p) {
		pgRepo.save(p);
	}
	
	public void saveSubmit(Submit s) {
        subRepo.save(s);
    }
	
	public void quizs(Quiz q)
	{
		qRepo.save(q);
	}
	public List<Patient_Teja> getAllPatients() {
		return pgRepo.findAll();
	}
	public void update(Patient_Teja p) {
		pgRepo.save(p);
	}
	
	public void delete(String id) {
		pgRepo.deleteById(id);
	}
	

}
