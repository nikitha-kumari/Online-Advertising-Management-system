
package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.dao.Patient_TejaDao;
import com.example.demo.entity.Patient_Teja;
import com.example.demo.entity.Quiz;
import com.example.demo.entity.Submit;
import com.example.demo.util.CaptchaUtil_Teja;

import cn.apiclub.captcha.Captcha;

@Controller
public class TejaController {
	
	@Autowired
	Patient_TejaDao pgDao;
	
	@RequestMapping("/")
	public String home() {
		return "home.jsp";
	}
	@RequestMapping("/Aboutus")
	public String aboutus()
	{
		return "Aboutus.html";
	}
	@RequestMapping("/ourclients")
	public String clients()
	{
		return "ourclients.html";
	}
	
	@RequestMapping("/projects")
	public String projects()
	{
		return "projects.html";
	}
	@RequestMapping("/contact")
	public String contact()
	{
		return "contact.html";
	}
	@RequestMapping("/bill")
	public String bill()
	{
		return "bill.html";
	}
	@RequestMapping("/cart.html")
	public String cart()
	{
		return "shopping-cart.html";
	}
	@RequestMapping("/payment")
	public String payment()
	{
		return "payment.html";
	}
	@RequestMapping("/newnav")
	public String newnav()
	{
		return "newnav.html";
	}
	@RequestMapping("/pay")
	public String pay()
	{
		return "pay.html";
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login1(Model m) {
		Captcha captcha =  CaptchaUtil_Teja.createCaptcha(150, 50);
		Patient_Teja p = new Patient_Teja();
		p.setHiddenCaptcha(captcha.getAnswer());
		p.setCaptcha("");
		p.setRealCaptcha(CaptchaUtil_Teja.encodeCaptcha(captcha));
		m.addAttribute("command", p);
		return "login.jsp";
	}
	
	@PostMapping("/loggedin")
	public String login2(Model m, @ModelAttribute("p") Patient_Teja p) {
	    System.out.println(p.getCaptcha());
	    System.out.println(p.getHiddenCaptcha());
	    if (p.getCaptcha().equals(p.getHiddenCaptcha())) {
	        if (pgDao.validateLogin(p)) {
	            Patient_Teja pf = pgDao.getDetailsById(p);
	            m.addAttribute("command", pf);
	            return "redirect:/newnav";
	        } else {
	            // Use the "error-message" class to style the error message
	            m.addAttribute("errorMessage", "Credential Error");
	            return "credential-error"; // This could be a custom error page
	        }
	    }
	    return "invalid";
	}


	
	
	@GetMapping("/register")
	
	public String register1(Model m) {
		Captcha captcha =  CaptchaUtil_Teja.createCaptcha(150, 50);
		Patient_Teja p = new Patient_Teja();
		p.setHiddenCaptcha(captcha.getAnswer());
		p.setCaptcha("");
		p.setRealCaptcha(CaptchaUtil_Teja.encodeCaptcha(captcha));
		m.addAttribute("command", p);
		return "register.jsp";
	}
	
	@PostMapping("/save")
	public String register2(@ModelAttribute("p") Patient_Teja p) {
		if(p.getCaptcha().equals(p.getHiddenCaptcha())) {
			pgDao.insert(p);
			return "redirect:login";
		}
		return "invalid";
	}
	@PostMapping("/save2")
	public String contanct(Submit s) {
			pgDao.saveSubmit(s);
			 return "redirect:/thankyou.html";
	}
	@PostMapping("/save3")
	public String customer(Quiz q) {
			pgDao.quizs(q);
			 return "redirect:/serviceimages.html";
	}
	@GetMapping("home")
    public String redirectToHome() {
        return "home.jsp";
    }
	
	@GetMapping("all")
	public String allPatients(Model m) {
		List<Patient_Teja> pl = pgDao.getAllPatients();
		m.addAttribute("pl", pl);
		return "show.jsp";
	}
	// Add this method to display the quiz page
	@GetMapping("quiz")
	public String quizPage(Model model) {
	    // You can customize this method to load questions or content for the quiz page
	    return "campaignquiz.jsp"; // Create a "quiz.jsp" page to display the questions and textboxes
	}

	
	
	@GetMapping("update/{id}")
	public String update1(Model m, @PathVariable String id) {
		Patient_Teja p = pgDao.getDetailsByIdOnly(id);
		m.addAttribute("command", p);
		return "/update.jsp";
		
	}
	
	@PostMapping("/update")
	public String update2(@ModelAttribute("p") Patient_Teja p) {
		pgDao.insert(p);
		return "redirect:all";
	}
	
	
	@GetMapping("/delete/{id}")
	public String delete(@PathVariable("id") String id) {
		pgDao.delete(id);
		return "redirect:/all";
	}
	
	
}
